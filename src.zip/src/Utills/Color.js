export const THEME_COLOR1= '#37306b';
export const THEME_COLOR2= '#66347e';
export const THEME_COLOR3= '#9e4784';
export const THEME_COLOR4= '#de4784';
export const WHITE= '#fff';
export const BLACK ='#000';
export const GRAY = '#909090'
