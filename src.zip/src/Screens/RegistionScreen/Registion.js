import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Registion = () => {
  return (
    <View>
      <Text>Registion</Text>
    </View>
  )
}

export default Registion

const styles = StyleSheet.create({})